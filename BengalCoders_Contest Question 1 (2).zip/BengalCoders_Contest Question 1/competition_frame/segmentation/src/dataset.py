# coding=gb2312
import torch
from PIL import Image
import os
import glob
from torch.utils.data import Dataset
import random
import numpy as np


class Train_Dateset_Loader(Dataset):
    def __init__(self, data_path):
        self.data_path = data_path
        self.imgs_path = glob.glob(os.path.join(data_path, 'train_images/*.png'))

    def augment(self, image, flipCode):
        image = np.array(image)
        img_pil = Image.fromarray(image)
        if flipCode == 1:
            img_pil = img_pil.transpose(Image.FLIP_LEFT_RIGHT)
        elif flipCode == 0:
            img_pil = img_pil.transpose(Image.FLIP_TOP_BOTTOM)
        elif flipCode == -1:
            img_pil = img_pil.transpose(Image.ROTATE_180)

        return img_pil

    def __getitem__(self, index):
        image_path = self.imgs_path[index]
        label_path = image_path.replace('train_images', 'train_Labels')
        label_path = label_path.replace('.png', '.png')  # todo ���±�ǩ�ļ����߼�

        image = Image.open(image_path)
        label = Image.open(label_path)

        image = image.resize((512, 512))
        label = label.resize((512, 512), resample=Image.NEAREST)

        image = image.convert('L')
        label = label.convert('L')

        label_array = np.array(label)

        label_array[label_array == 255] = 1

        label = Image.fromarray(label_array)

        flipCode = random.choice([-1, 0, 1, 2])
        if flipCode != 2:
            image = self.augment(image, flipCode)
            label = self.augment(label, flipCode)
        image = image.resize((512, 512))
        image = np.expand_dims(image, axis=0)
        label = label.resize((512, 512))
        label = np.expand_dims(label, axis=0)
        return image, label

    def __len__(self):
        return len(self.imgs_path)