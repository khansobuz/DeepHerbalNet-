# coding=gb2312
import time
from PIL import Image
import numpy as np
# import cv2
import os
import torch.nn.functional as F
from tqdm import tqdm
from model_util import UNet  # import��ģ�Ϳɸ���ʵ���޸�
import torch

'''
    test.py���޸ĵĲ��ֽ������֣�
        1��from model_util import UNet  # import��ģ�Ϳɸ���ʵ���޸�
        2��cal_f1_score���ļ�·�����޸�
        3��ģ�͵��ã�model = resnet18(num_classes=total_classes, include_top=True)  # �ɸ���ʵ�ʵ���ģ��
'''


def f_score(inputs, target, beta=1, smooth=1e-5, threhold=0.5):
    # ���������Ŀ���ά��
    n, h, w = inputs.size()
    nt, ht, wt = target.size()

    if h != ht or w != wt:
        inputs = F.interpolate(inputs.unsqueeze(0), size=(ht, wt), mode="bilinear", align_corners=True)[0]

    temp_inputs = inputs.view(n, -1)
    temp_target = target.view(n, -1)

    # ����TP, FP, FN
    temp_inputs = (temp_inputs > threhold).float()
    tp = torch.sum(temp_target * temp_inputs, dim=1)
    fp = torch.sum(temp_inputs, dim=1) - tp
    fn = torch.sum(temp_target, dim=1) - tp

    score = ((1 + beta**2) * tp + smooth) / ((1 + beta**2) * tp + beta**2 * fn + fp + smooth)
    score = torch.mean(score)

    return score


def cal_f1_score(test_dir="../data2/test_images", pred_dir="../results", gt_dir="../data2/test_Labels",
                 model_path='best_model01.pth'):

    if not os.path.exists(pred_dir):
        os.makedirs(pred_dir)
    print("---------------------------------------------------------------------------------------")
    print("����ѵ���õ�ģ��,ģ��λ��{}".format(model_path))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = UNet(n_channels=1, n_classes=1)  # �ɸ���ʵ�ʵ���ģ��
    net.to(device=device)
    net.load_state_dict(torch.load(model_path, map_location=device))
    net.eval()
    print("ģ�ͼ��سɹ���")

    img_names = os.listdir(test_dir)
    image_ids = [image_name.split(".")[0] for image_name in img_names]

    print("---------------------------------------------------------------------------------------")
    print("�Բ��Լ�������������")
    time.sleep(1)

    predictions = []
    gt_labels = []

    for image_id in tqdm(image_ids):
        image_path = os.path.join(test_dir, image_id + ".png")
        img = Image.open(image_path).convert('L')
        origin_shape = img.size
        img = img.resize((512, 512))

        img_array = np.array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = np.expand_dims(img_array, axis=0)

        img_tensor = torch.from_numpy(img_array)
        img_tensor = img_tensor.to(device=device, dtype=torch.float32)
        pred = net(img_tensor)
        pred = np.array(pred.data.cpu()[0])[0]
        pred[pred >= 0.5] = 255
        pred[pred < 0.5] = 0

        pred_image = Image.fromarray(pred, mode = "F")
        pred_resized = pred_image.resize((origin_shape[1], origin_shape[0]), resample=Image.NEAREST)

        pred_resized.save(os.path.join(pred_dir, image_id + ".tiff"))

        predictions.append(pred)

        gt_path = os.path.join(gt_dir, image_id + ".png")
        gt_label = Image.open(gt_path).convert('L')
        gt_label_img = gt_label.resize((512, 512))
        gt_label_img_array = np.array(gt_label_img)

        gt_labels.append(gt_label_img_array)

    print("���Լ�������������")

    print("��ʼ����f1_score����ָ��")
    predictions = np.array(predictions)
    gt_labels = np.array(gt_labels)
    predictions[predictions >= 0.5] = 1
    predictions[predictions < 0.5] = 0
    gt_labels[gt_labels >= 0.5] = 1
    gt_labels[gt_labels < 0.5] = 0

    predictions = torch.from_numpy(predictions)
    gt_labels = torch.from_numpy(gt_labels)

    results = f_score(predictions, gt_labels, beta=1, smooth=1e-5, threhold=0.5).item()
    print("F1-Score:", results)

    current_dir = os.getcwd()
    parent_dir = os.path.dirname(current_dir)
    file_name = f"{parent_dir}/results/output.txt"
    with open(file_name, "w") as file:
        file.write(str(results))
    print("���Խ���ѱ��浽", file_name)


if __name__ == '__main__':
    cal_f1_score(test_dir="../data2/test_images",  # ���Լ�·��
                 pred_dir="../results",  # ���Լ������������·��
                 gt_dir="../data2/test_Labels",  # ����mask·��
                 model_path='Tongue_best_model.pth')  # ѵ���õ�ģ��·��